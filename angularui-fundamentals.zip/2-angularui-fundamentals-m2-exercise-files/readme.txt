Run "bower install" to restore all JavaScript files to the /src/lib folder.

Run "npm install" from the console prior to running any gulp tasks.

Make sure that the "X-ZUMO-APPLICATION" header in /src/app/services/elite-api.service.js (line #27) matches the key in your Azure Mobile Service.

