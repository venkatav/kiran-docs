Run "npm install" from the console prior to running any gulp tasks.

Make sure that the "X-ZUMO-APPLICATION" header in /setup/elite-schedule-ams-seed-data.js (line #36) matches the key in your Azure Mobile Service.


To run the back end setup (Azure Mobile Services) process, cd into the "setup" directory and run "npm install" from there to ensure node modules required for set up are installed.

Make sure that the "X-ZUMO-APPLICATION" header in /src/app/services/elite-api.service.js (line #27) matches the key in your Azure Mobile Service.