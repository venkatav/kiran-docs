var mainApp = angular.module('mainApp', []);


mainApp.controller('Ctrl', function($scope,$http){

	$http.get('json/menu2.json').success(function (response){
		$scope.menu = response;
	});
});

mainApp.directive('toggleNavigation', function() {
	return{
		restrict: 'A',
		link: function(scope, element, attrs){
			element.bind('click', function() {
				$('#jore-nav').toggleClass("display-none"); // show Jore Nav
				$('#base-area').toggleClass("display-none"); // hide all background content
			});

		}
	}
});

mainApp.directive('toggleSubnav', function() {
	return{
		restrict: 'A',
		link: function(scope, element, attrs){
			element.bind('click', function() {
             $(this).next().slideToggle(attrs, function() {});
			});
		}
	}
});

