grunt and gulp demos
===========

Simple grunt and gulp tasks that demonstrate how to use JavaScript task automation on a simple Angular app.

Slides can be located [here](http://www.johnpapa.net/gulp-and-grunt-at-anglebrackets/)



## Starter set of middleware and packages for MEAN server

`npm install express morgan method-override compression body-parser cors debug serve-static static-favicon --save`