/*
 * Create references
 */




/*
 * Auto load all gulp plugins
 */



/*
 * Load common utilities for gulp
 */



/*
 * Create comments for minified files
 */



/*
 * Could use a product/development switch.
 * Run `gulp --production`
 */




/*
 * Lint the code
 */




/*
 * Minify and bundle the JavaScript
 */





/*
 * Minify and bundle the CSS
 */




/*
 * Compress images
 */





/*
 * Bundle the JS, CSS, and compress images.
 * Then copy files to production and show a toast.
 */




/*
 * Remove all files from the output folder
 */



/*
 * Watch file and re-run the linter
 */





