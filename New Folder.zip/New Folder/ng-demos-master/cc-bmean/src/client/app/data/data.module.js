(function () {
    'use strict';

    angular.module('app.data', [

        // Also uses these, but we get them from core:
//        'common',
//        'blocks.exception', 'blocks.logger',
//        'breeze.angular',   // tells breeze to use $q instead of Q.js
//        'breeze.directives',// breeze validation directive (zValidate)
//        'ngzWip'            // zStorage and zStorageWip
    ]);
})();