//        .pipe(plug.header(fs.readFileSync('./gulp/copyright.js'), {version: pkg.version}))

/**
 * @author John Papa
 * @version:
 *     <%= version %>
 * @links
 *     http://github.com/johnpapa/ng-demos
 *     http://twitter.com/johnpapa
 *     http://johnpapa.net
 * @source
 *     http://github.com/johnpapa/ng-demos
 * @license:
 *     MIT License http://www.opensource.org/licenses/mit-license.php
 */