(function() {
    'use strict';

    angular.module('blocks.router', [
        'ngRoute',
        'blocks.logger'
    ]);
})();
