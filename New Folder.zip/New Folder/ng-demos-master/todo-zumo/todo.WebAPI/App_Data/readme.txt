﻿This placeholder document is necessary so Visual Studio will publish the folder and git will commit it.

The application creates and populates the Todo.temp.mdf localdb database here in App_Data
That database is not part of the project structure; it becomes visibly when you "show all files".