#HotTowel Angular 
... has moved to [https://github.com/johnpapa/generator-hottowel]
(https://github.com/johnpapa/generator-hottowel)