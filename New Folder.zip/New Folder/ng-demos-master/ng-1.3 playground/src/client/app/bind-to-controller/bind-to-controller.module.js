(function() {
    'use strict';

    angular.module('app.bind-to-controller', []);
})();
