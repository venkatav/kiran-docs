(function() {
    'use strict';

    angular.module('app.other', []);
    angular.module('app.dummy', []);
})();
