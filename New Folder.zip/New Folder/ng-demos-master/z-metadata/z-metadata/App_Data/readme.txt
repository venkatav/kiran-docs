Text document is necessary so VS will publish and git will commit the otherwise empty folder

Application creates and populates the Todo.temp.sdf SQL CE 4 database if it does not exist in this folder. That database is not part of the project structure; it becomes visibly when you "show all files".