﻿/* main: startup script creates the 'todo' module */
(function() {

    // app module depends on "Breeze Angular Service"
    angular.module('app', ['breeze.angular']);

})();