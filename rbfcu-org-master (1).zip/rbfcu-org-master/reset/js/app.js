var mainApp = angular.module('mainApp', [])
    .controller('Ctrl', function($scope, $http) {

        $http.get('json/menu.json').success(function(response) {
            $scope.menu = response;
        });

    })
    .directive('toggleNavigation', function() {
        return {
            restrict: 'A',
            link: function(scope, element, attrs) {
                element.bind('click', function() {
                    $('#jore-nav').toggleClass("display-none"); // show Jore Nav
                    $('#base-area').toggleClass("display-none");
                    $('.bottombar-cntr').toggleClass("display-none");
                });

            }
        }
    })
    .directive('toggleSubnav', function() {
        return {
            restrict: 'A',
            link: function(scope, element, attrs) {
                element.bind('click', function() {
                    $(this).next().slideToggle(attrs, function() {});
                });
            }
        }
    })
    .directive('aboveSegment', function() {
        return {
            restrict: 'A',
            templateUrl: 'incl/above-seg.html'
        }
    })
    .directive('notificationSegment', function() {
        return {
            restrict: 'A',
            templateUrl: 'incl/notification-seg.html'
        }
    })
    .directive('flyerSegment', function() {
        return {
            restrict: 'A',
            templateUrl: 'incl/flyer-seg.html'
        }
    })
    .directive('servicesSegment', function() {
        return {
            restrict: 'A',
            templateUrl: 'incl/services-seg.html'
        }
    })
    .directive('newsSegment', function() {
        return {
            restrict: 'A',
            templateUrl: 'incl/news-seg.html'
        }
    })
    .directive('testimonialSegment', function() {
        return {
            restrict: 'A',
            templateUrl: 'incl/testimonial-seg.html'
        }
    })
    .directive('relatedSegment', function() {
        return {
            restrict: 'A',
            templateUrl: 'incl/related-seg.html'
        }
    })
    .directive('checkingrelatedSegment', function() {
        return {
            restrict: 'A',
            templateUrl: 'incl/_checking/related-seg.html'
        }
    })
    .directive('socialSegment', function() {
        return {
            restrict: 'A',
            templateUrl: 'incl/social-seg.html'
        }
    })
    .directive('footerSegment', function() {
        return {
            restrict: 'A',
            templateUrl: 'incl/footer-seg.html'
        }
    })
    .directive('announceSegment', function() {
        return {
            restrict: 'A',
            templateUrl: 'incl/announce-seg.html'
        }
    })
    .directive('stackSegment', function() {
        return {
            restrict: 'A',
            templateUrl: 'incl/_checking/stack-seg.html'
        }
    })
    .directive('describeSegment', function() {
        return {
            restrict: 'A',
            templateUrl: 'incl/_checking/describe-seg.html'
        }
    })
